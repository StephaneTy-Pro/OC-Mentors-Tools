//
// celui là ne semble pas fonctionner
console.log(" << ----- %s ----- >> ", "onDocumentIdle.js");
