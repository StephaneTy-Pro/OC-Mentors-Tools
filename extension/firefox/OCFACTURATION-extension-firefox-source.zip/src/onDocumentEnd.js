/**
 * Version de base
 */
// DEBUT CHARGEMENT-------------------------------------------------------------
console.log(" << ----- %s ----- >> ", "SOF onDocumentEnd.js");

// FUNCTIONS
/*
 * CDC
 *
 * Ce bloc de fonction doit permettre
 *  - de charger un script
 *
 */

/*
 * Note STT: je pensais mettre un état loading, idle, loaded, failed ... pour
 * l'insertion de script mais en fait il n'y a que deux état chargé ou pas
 * on opte donc pour false / true
 */

/**
 * Includes a script from a given URL and returns a Promise that resolves when the script is loaded.
 * @param {string} url - The URL of the script to include. Cannot be null.
 * @param {object} [options] - An object containing options for the script inclusion.
 * @param {string} [options.id] - The ID to assign to the script element. Default is null.
 * @param {boolean} [options.bRemoveOnLoad] - Whether to remove the script element after it has loaded. Default is false.
 * @param {string} [options.initFunctionName] - The name of the initialization function to call when the script has loaded. Default is 'init'.
 * @returns {Promise} A Promise that resolves when the script has loaded or rejects if there was an error.
 * @throws {Error} If the URL is null.
 * @throws {Error} If the script cannot be reached.
 *
 * Inclut un script à partir d'une URL donnée et retourne une promesse qui se résout lorsque le script est chargé.
 * @param {string} url - L'URL du script à inclure. Ne peut pas être null.
 * @param {object} [options] - Un objet contenant des options pour l'inclusion du script.
 * @param {string} [options.id] - L'ID à attribuer à l'élément script. La valeur par défaut est null.
 * @param {boolean} [options.bRemoveOnLoad] - Indique si l'élément script doit être supprimé après son chargement. La valeur par défaut est false.
 * @param {string} [options.initFunctionName] - Le nom de la fonction d'initialisation à appeler lorsque le script est chargé. La valeur par défaut est 'init'.
 * @returns {Promise} Une promesse qui se résout lorsque le script est chargé ou qui est rejetée en cas d'erreur.
 * @throws {Error} Si l'URL est null.
 * @throws {Error} Si le script ne peut pas être atteint.
 */
const includeScript = async function(url, options) {

	const sHeader = "includeScript()";
	const C = {
		APP_DEBUG_STYLE: [
			"color: #373737",
			"background-color: #CC6",
			"padding: 2px 4px",
			"border-radius: 2px"
		].join(";"),
		APP_WARN_STYLE: [
			"color: yellow",
			"background-color: #CC6",
			"padding: 2px 4px",
			"border-radius: 2px"
		].join(";"),
		APP_ERROR_STYLE: [
			"color: red",
			"background-color: #CC6",
			"padding: 2px 4px",
			"border-radius: 2px"
		].join(";"),
		APP_INFO_STYLE: [
			"color: cyan",
			"background-color: #CC6",
			"padding: 2px 4px",
			"border-radius: 2px"
		].join(";"),
	}

	const bVerbose = false;


	if (url === null) {
		return Promise.reject("Erreur : la valeur de l'url est nulle");
	}

	const defaultOptions = {
		id: null,
		bRemoveOnLoad: false,
		initFunctionName: 'init', // ou null au choix
	};
	// generate final options
	const mergedOptions = Object.assign({}, defaultOptions, options);

	return new Promise((resolve, reject) => {
		const script = document.createElement('script');

		if (mergedOptions.id !== null) {
			script.id = mergedOptions.id;
		}

		// visiblement ce statut se transforme trop vite pour pouvoir etre utilisé par le mutation observer du bootstrap
		script.setAttribute('data-loaded', 'false');

		//script.onload = function() {
		script.onload = async function(event) {
			if(bVerbose===true){console.log("%c%s%c event onload reçu url:%s", C.APP_DEBUG_STYLE, sHeader,"",url);}
			if ( mergedOptions.initFunctionName !== null  && window.postMessage){

				// puisque je ne peux pas utiliser event.source on va tenter une autre approche
				const targetElement = event.explicitOriginalTarget;
				if( targetElement ){
				// Ajouter l'attribut de données "loaded_true" à l'élément cible
					targetElement.setAttribute('data-loaded', 'true');
					if(bVerbose===true){ console.log('L\'attribut de données "loaded_true" a été ajouté à l\'élément :', targetElement);}
				}

				// envoyer un message général qui sera reçu par window.addEventListener("message", receiveMessage, false);
				if(bVerbose===true){ console.log("%c%s%cwill post a message to <window>: %s", C.APP_DEBUG_STYLE, sHeader, "", mergedOptions.initFunctionName); }
				window.postMessage({ type: mergedOptions.initFunctionName, functionName: 'maFonction_postMessage', stt_origin:'onDocumentEnd<script.onload>', boot:"_test" }, '*');

				// ça semble ne pas fonctionne mais ça reste à creuser
				// on va doubler avec un evenement
				// a tester
				//const event = new CustomEvent('init', { detail: { functionName: 'maFonction_customeEvent' } });
				//script.dispatchEvent(event);

			}

			if (mergedOptions.bRemoveOnLoad) {
				if(bVerbose===true){ console.log("includeScript() suppression du noeud du script"); }
				this.remove();
			}
			resolve();
		};

		script.onerror = function(errorEvent) {
			//console.error("includeScript(), on a un probleme => suppression du noeud du script");
			this.remove();
			//console.log("includeScript(), puis on rejette");
			const error = {
				message: "Could'nt reach url",
				url: url,
				event: errorEvent
			};
			reject(error);
		};

		script.setAttribute('data-origin', 'includeScript()');
		script.src = url;
		(document.head || document.documentElement).appendChild(script);
	});
}

// NOTESTT par local on entend dans l'extension livrée

/**
 * Charge un script depuis une URL principale et une URL de secours, avec prise en charge des URL locales et distantes.
 *
 * @param {string} primaryUrl - L'URL principale du script à charger.
 * @param {string} fallbackUrl - L'URL de secours du script à charger.
 * @param {string} [message] - Le message à envoyer avec l'événement 'scriptLoaded'.
 * @returns {Promise<string>} Une promesse qui se résout avec l'URL du script chargé.
 */
async function includeScriptFromExtensionWithFallback(primaryUrl, fallbackUrl, message) {

	try {
		// Tente de charger le script depuis l'URL principale
		const primaryScriptUrl = await includeScriptFromExtensionOrUrl(primaryUrl, message);
		//console.log(`includeScriptFromExtensionWithFallback():Fichier chargé : ${primaryScriptUrl}`);
		return primaryScriptUrl;
	} catch (error) {
		console.warn(`Échec du chargement du fichier ${primaryUrl}, utilisation de l'URL de secours.`, error);
		// Another try/catch error block !!!!!
		try {
			// Tente de charger le script depuis l'URL de secours
			const fallbackScriptUrl = await includeScriptFromExtensionOrUrl(fallbackUrl, message);
			//console.log(`Fichier chargé depuis l'URL de secours : ${fallbackScriptUrl}`);
			return fallbackScriptUrl;
		} catch (error) {
			console.error(`Échec du chargement du fichier depuis l'URL de secours : ${fallbackUrl}`, error);
			throw error; // Renvoie l'erreur pour qu'elle soit traitée par le bloc catch du niveau supérieur
		}

	}
}

/**
 * Charge un script depuis une URL locale ou distante.
 *
 * @param {string} url - L'URL du script à charger.
 * @param {string} [message] - Le message à envoyer avec l'événement 'scriptLoaded'.
 * @returns {Promise<string>} Une promesse qui se résout avec l'URL du script chargé.
 */
async function includeScriptFromExtensionOrUrl(url, message) {
	let scriptUrl;
	const SCRIPT_LOADED_EVENT= 'includeScriptFromExtensionOrUrl::onload';


	if (url.startsWith('http://') || url.startsWith('https://')) {
		// L'URL est distante, on l'utilise telle quelle
		scriptUrl = url;
	} else {
		// L'URL est locale, on utilise l'API runtime.getURL pour obtenir l'URL complète
		scriptUrl = browser.runtime.getURL(url);
	}

	//console.log(`On tente de lancer le fichier : ${scriptUrl}`);

	// Charge le script et renvoie une promesse
	return includeScript(scriptUrl)
	.then(() => {
		//console.log(`includeScriptFromExtensionOrUrl():Fichier chargé : ${url}`);
		if (message) {
			document.dispatchEvent(new CustomEvent(SCRIPT_LOADED_EVENT, { detail: { message } }));
		}
		return url;
	})
	.catch(error => {
		console.error(`Échec du chargement du fichier : ${url}`, error);
		throw error; // Renvoie l'erreur pour qu'elle soit traitée par le bloc catch du niveau supérieur
	});

}

// ASYNC IIFE FUNCTION

(async function(_G={}) { // _G globals are  the context bind to IIFE at bottom  })(context);
	console.log(" << ----- %s ----- >> ", "onDocumentEnd.async function()");

    const scripts = [
		{ url: 'http://localhost:8080/scripts/bootstrap.js', fallback: './src/bootstrap.js' },
		{ url: 'http://localhost:8080/scripts/openclassrooms.api.js', fallback: './src/openclassrooms.api.js' },
		{ url: 'http://localhost:8080/scripts/list_sessions.js', fallback: './src/list_sessions.js' },
		{ url: 'http://localhost:8080/scripts/lib.accounting.js', fallback: './src/lib.accounting.js' },
		{ url: 'http://localhost:8080/scripts/gsheet.api.nolibs.js', fallback: './src/gsheet.api.nolibs.js' },
		{ url: 'http://localhost:8080/scripts/jsonata.min.js', fallback: './src/jsonata.min.js' },
		{ url: 'http://localhost:8080/scripts/sandbox_message.js', fallback: './src/sandbox_message.js' },
	];

	for (const script of scripts) {
		try {
			await includeScriptFromExtensionWithFallback(script.url, script.fallback);
		} catch (e) {
			console.log('Error ', e);
		}
	}

	// NOUVELLE APPROCHE
	// SAUVEGARDER DANS LE LOCALSTORAGE mais ce dernier n'est surement pas visible des documents
	/*
	fetch(browser.runtime.getURL('./src/gsheet.api.nolibs.js'))
		.then((response) => response.text())
		.then((fileContent) => {
			console.log(fileContent);
		// Stockez le fichier dans le stockage local de l'extension
		browser.storage.local.set({ '/src/gsheet.api.nolibs.js': fileContent });
		console.log("SAVED");
		browser.storage.local.get('/src/gsheet.api.nolibs.js').then((data) => {

			console.log(data);

		  const exampleScript = data.exampleScript;

		  // Envoyez le script au script injecté
		  console.log({ type: 'exampleScript', script: exampleScript }, '*');
		});
	});
	*/

	////////////////////
	const MSG = 'includeScriptFromExtensionOrUrl::onload';
	window.addEventListener(MSG, (event) => {
		const createWorkerFromJSON = event.detail;
		console.log("/!\ MESSAGE: %s RECU par onDocumentEnd::async function()", MSG);
		// Use the createWorkerFromJSON function here
		console.log("Je peux maitenant utiliser la fonction %o qui serait dans mon fichier chargé", event.detail);
		//const worker = createWorkerFromJSON('http://localhost:8080/scripts/lib.accounting.js');
		console.log("pour information l'evenement reçu était %o", event);
	});
	//////////////////
	console.log(" >> ----- %s ----- << ", "onDocumentEnd.async function()");


	// CLEAN
	// Fonction pour ajouter le script avec l'ID '_STOP_OBSERVER_'
	function addStopObserverScript() {
		const stopObserverScript = document.createElement('script');
		stopObserverScript.id = '_STOP_OBSERVER_';
		stopObserverScript.textContent = '// Ce script est utilisé pour arrêter l\'observer';
		document.head.appendChild(stopObserverScript);
	}
	addStopObserverScript();

})();


// FIN CHARGEMENT --------------------------------------------------------------
console.log(" >> ----- %s ----- << ", "EOF onDocumentEnd.js");
