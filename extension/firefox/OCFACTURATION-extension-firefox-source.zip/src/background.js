
/*
// Écoutez l'événement d'installation ou de mise à jour de l'extension
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install' || details.reason === 'update') {
    // Recherchez les onglets correspondant au motif de filtre d'URL
    browser.tabs.query({ url: "https://openclassrooms.com/**" }, (tabs) => {
      tabs.forEach((tab) => {
		  console.log('wanna update %o', tab);
        // Injectez le script dans l'onglet uniquement s'il n'a pas encore été exécuté
        browser.tabs.executeScript(tab.id, {
          file: 'content_script.js',
          runAt: 'document_idle',
          allFrames: false
        }, () => {
          if (browser.runtime.lastError) {
            console.error(browser.runtime.lastError.message);
          }
        });
      });
    });
  }
});
*/


