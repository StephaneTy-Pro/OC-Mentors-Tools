/**
 * Version de base
 */
// DEBUT CHARGEMENT-------------------------------------------------------------
console.log(" << ----- %s ----- >> ", "SOF onDocumentStart.js");

// FUNCTIONS
// CES FONCTIONS SONT DES HELPER CHARGES INCLUS VIA YPP
/*
async function includeScriptFromExtensionWithFallback(primaryUrl, fallbackUrl, message) {}
async function includeScriptFromExtensionOrUrl(url, message) {}
function includeScript(url, options) {}
*/
// ASYNC IIFE FUNCTION

(async function() {
	console.log(" << ----- %s ----- >> ", "onDocumentEnd.async function()");


	////////////////////
	const MSG = 'includeScriptFromExtensionOrUrl::onload';
	window.addEventListener(MSG, (event) => {
		const createWorkerFromJSON = event.detail;
		console.log("/!\ MESSAGE: %s RECU par onDocumentStart::async function() avec evenement", MSG, event);
	});
	//////////////////
	console.log(" >> ----- %s ----- << ", "onDocumentStart.async function()");


})();


// FIN CHARGEMENT --------------------------------------------------------------
console.log(" >> ----- %s ----- << ", "EOF onDocumentStart.js");
