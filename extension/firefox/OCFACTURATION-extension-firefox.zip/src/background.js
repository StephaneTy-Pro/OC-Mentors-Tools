
/*
// Écoutez l'événement d'installation ou de mise à jour de l'extension
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install' || details.reason === 'update') {
    // Recherchez les onglets correspondant au motif de filtre d'URL
    browser.tabs.query({ url: "https://openclassrooms.com/**" }, (tabs) => {
      tabs.forEach((tab) => {
		  console.log('wanna update %o', tab);
        // Injectez le script dans l'onglet uniquement s'il n'a pas encore été exécuté
        browser.tabs.executeScript(tab.id, {
          file: 'content_script.js',
          runAt: 'document_idle',
          allFrames: false
        }, () => {
          if (browser.runtime.lastError) {
            console.error(browser.runtime.lastError.message);
          }
        });
      });
    });
  }
});
*/
/*
export {
	inject
};
* */


// https://github.com/gildas-lormeau/SingleFile/blob/master/src/lib/single-file/core/bg/scripts.js
// mais ma version fonctionne mieux on dirait


console.log("Je suis background.js");

/* global globalThis */

const browser = globalThis.browser;
const _document = globalThis.document;
const Document = globalThis.Document;

console.log("browser", browser);
console.log("document", _document);
console.log("Document", Document);
console.log("Window", window);

browser.runtime.onInstalled.addListener((details) => {

	console.log("On installed : %o", details);

	browser.tabs.query({ url: "https://openclassrooms.com/**" }, (tabs) => {

		console.log("tabs %o",tabs);

	})

});

// On tente un écouteur d'évenement pour réagir

// Écoutez les messages envoyés depuis la page actuelle
// ça ne fonctionne pas car c'est sur la page "html" qui sert de conteneur au fichier background.js
window.addEventListener("message", function(event) {

	console.log("Dans le background on a intercepté un message", event);


  // Vérifiez que le message provient de la page actuelle
  if (event.source !== window) {
    return;
  }

  // Traitez le message et envoyez une réponse
  const message = event.data;
  const response = processMessage(message);
  event.source.postMessage(response, event.origin);
});

// écouter les messages envoyés par le content script
browser.runtime.onMessage.addListener((message) => {
	console.log("Message reçu");
	if (message.type === 'content-script-loaded') {
		// faire quelque chose lorsque le content script est chargé
		console.log('Content script chargé !');
	}
});
// écouter les messages envoyés par le content script
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.type === 'dom-modified') {
		// faire quelque chose lorsque le DOM est modifié
		console.log('DOM modifié !');

		const response = 'Hello from background script!';

		// envoyer une réponse à idle.js
		console.log("VA REPONDRE");
		sendResponse({ type: 'response', data: response });
		console.log("REPONSE ENVOYEE");

	}
});




browser.runtime.onMessage.addListener((message, sender) => {
	console.log("............ ********* Le fichier background.js à reçu un message \nmessage:%o, \sender:%o", message, sender);
});

