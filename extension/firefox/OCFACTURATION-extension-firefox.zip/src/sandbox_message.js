

// DEBUT CHARGEMENT-------------------------------------------------------------
console.log(" << ----- %s ----- >> ", "SOF sandbox_message.js");
function receiveMessage(event)
{

	console.log("sanbox_message receive %o", event);
	// note STT comme c'est le script qui envoie le message on ne peut pas filtrer


  if (event.boot){ event.boot(); }
}

function _boot(){
	console.log("Cette fonction est lancée par le onload du script par l'intermediaire de onDocumentEnd");
}

window.addEventListener("message", receiveMessage, false);

var module = {name:"sandbox_message"}
onModuleReady(module); // lance la fonction window.onModuleReady définit dans le fichier bootstrap


// --- ENVOYONS UN MESSAGE
const message = {
  type: "myMessageType",
  data: "myData"
};

// Envoyez le message à la page d'arrière-plan
console.log("Envoi du message");
window.postMessage(message, "*");

/* n'existe pas
var ls = window.content.localStorage;
var item = ls.getItem("myvariable")
console.log("A t'on trouvé ls ?", item);
*/

// FIN CHARGEMENT --------------------------------------------------------------
console.log(" >> ----- %s ----- << ", "EOF sandbox_message.js");
