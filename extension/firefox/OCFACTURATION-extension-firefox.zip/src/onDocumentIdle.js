//
// celui là ne semble pas fonctionner
console.log(" << ----- %s ----- >> ", "SOF onDocumentIdle.js");

console.log("Va envoyer le message:'content-script-loaded'");
browser.runtime.sendMessage({ type: 'content-script-loaded' });

// créer un observateur de mutation pour écouter les modifications du DOM
const observer = new MutationObserver(() => {
  // envoyer un message au background script lorsqu'une modification est détectée
  browser.runtime.sendMessage({ type: 'dom-modified' });
});

// configurer l'observateur pour observer les modifications du nœud racine
observer.observe(document.documentElement, { childList: true, subtree: true });


// écouter les messages envoyés par background.js
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {


	console.log("OK ai une répone est elle de type réponse ?");

  if (message.type === 'response') {
    // faire quelque chose avec la réponse
    console.log('Réponse reçue de (background.js):', message.data);
  }
});


// créer une balise commentaire
const comment = document.createComment('injected by content script');

// ajouter un écouteur d'événement à la balise commentaire
comment.addEventListener('message_from_idle', (event) => {
  console.log('Message reçu :', event.detail);
});

// injecter la balise commentaire dans la page
document.body.appendChild(comment);

// envoyer un message à la balise commentaire
comment.dispatchEvent(new CustomEvent('message_from_idle', { detail: 'Hello from content script!' }));

// FIN CHARGEMENT --------------------------------------------------------------
console.log(" >> ----- %s ----- << ", "EOF onDocumentIdle.js");
